###
Binded these templates here from so many repos as One!
Great Love to the guys who made it!
