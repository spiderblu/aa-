# Collection of SAP Nuclei Templates

This repository contains a collection of templates for the nuclei scanner related to SAP.

## Tool information

- Nuclei: https://github.com/projectdiscovery/nuclei
- Community templates: https://github.com/projectdiscovery/nuclei-templates

## SAP templates

- SAPRouter detection
- SAPRouter route information dump 